/*
 * imu.h
 *
 *  Created on: Apr 1, 2025
 *      Author: William
 */

#ifndef INC_IMU_H_
#define INC_IMU_H_

#include "main.h"
#include <stdbool.h>

/* Define sensor addresses ---------------------------------------------------*/
#define LIS3DH_ADDR  0x18   // 7-bit address for LIS3DH accelerometer
#define LIS2MDL_ADDR 0x1E   // 7-bit address for LIS2MDL magnetometer

/* Function prototypes -------------------------------------------------------*/
/**
  * @brief  Initialize the IMU sensors (LIS3DH and LIS2MDL)
  * @retval bool: true if initialization successful, false if failed
  */
bool IMU_Init(void);

/**
  * @brief  Read current data from all IMU sensors
  * @retval None
  */
void IMU_ReadData(void);

/**
  * @brief  Display current IMU sensor readings on the specified UART
  * @retval None
  */
void IMU_DisplayData(void);

/**
  * @brief  Get the current accelerometer X, Y, Z values
  * @param  x_out: Pointer to store X acceleration (g)
  * @param  y_out: Pointer to store Y acceleration (g)
  * @param  z_out: Pointer to store Z acceleration (g)
  * @retval None
  */
void IMU_GetAcceleration(float *x_out, float *y_out, float *z_out);

/**
  * @brief  Get the current magnetometer X, Y, Z values
  * @param  x_out: Pointer to store X magnetic field (gauss)
  * @param  y_out: Pointer to store Y magnetic field (gauss)
  * @param  z_out: Pointer to store Z magnetic field (gauss)
  * @retval None
  */
void IMU_GetMagneticField(float *x_out, float *y_out, float *z_out);

/**
  * @brief  Get temperature readings from both sensors
  * @param  accel_temp: Pointer to store accelerometer temperature (°C)
  * @param  mag_temp: Pointer to store magnetometer temperature (°C)
  * @retval None
  */
void IMU_GetTemperature(float *accel_temp, float *mag_temp);

#endif /* INC_IMU_H_ */
