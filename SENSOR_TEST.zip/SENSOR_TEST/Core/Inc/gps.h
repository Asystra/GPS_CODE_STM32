/*
 * gps.h
 *
 *  Created on: Apr 1, 2025
 *      Author: William
 */

#ifndef INC_GPS_H_
#define INC_GPS_H_
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdbool.h>

/* Define buffer size for NMEA parsing */
#define BUFFER_SIZE 512

/* GPS data structure */
typedef struct {
    float latitude;
    float longitude;
    char lat_dir;
    char lon_dir;
    int fix_quality;
    int satellites;
    float hdop;
    float altitude;
    char valid;

    // Additional fields for GSA parsing (for PDOP, HDOP, VDOP)
    int fix_type;       // 1 = no fix, 2 = 2D fix, 3 = 3D fix
    float pdop;         // Position dilution of precision
    float hdop_gsa;     // Horizontal dilution of precision from GSA
    float vdop;         // Vertical dilution of precision

    // Active satellite IDs
    int sats_used[12];

    // Raw NMEA sentence (for debugging)
    char last_sentence[BUFFER_SIZE];
} GPS_Data;

/* Function prototypes -------------------------------------------------------*/
/**
  * @brief  Initialize the GPS module
  * @retval None
  */
void GPS_Init(void);

/**
  * @brief  Process incoming GPS data from UART
  * @retval None
  */
void GPS_ProcessData(void);

/**
  * @brief  Display current GPS data
  * @retval None
  */
void GPS_DisplayData(void);

/**
  * @brief  Get the current GPS data struct
  * @retval GPS_Data: Current GPS data
  */
GPS_Data GPS_GetData(void);

/**
  * @brief  Check if valid GPS fix is available
  * @retval bool: true if valid fix available, false otherwise
  */
bool GPS_HasValidFix(void);


#endif /* INC_GPS_H_ */
