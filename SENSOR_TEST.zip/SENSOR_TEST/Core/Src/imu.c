/*
 * imu.c
 *
 *  Created on: Apr 1, 2025
 *      Author: William
 */


/* Includes ------------------------------------------------------------------*/
#include "imu.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/* Private variables ---------------------------------------------------------*/
/* Variables for LIS3DH accelerometer */
static float x_accel = 0.0f, y_accel = 0.0f, z_accel = 0.0f;
static float lis3dh_temp = 0.0f;

/* Variables for LIS2MDL magnetometer */
static float x_mag = 0.0f, y_mag = 0.0f, z_mag = 0.0f;
static float lis2mdl_temp = 0.0f;

/* Private function prototypes -----------------------------------------------*/
static HAL_StatusTypeDef LIS3DH_Init(void);
static HAL_StatusTypeDef LIS2MDL_Init(void);
static void LIS3DH_CalcValue(uint16_t raw_value, float *final_value, bool isAccel);
static void LIS3DH_ReadData(uint8_t reg, float *final_value, bool isAccel);
static void LIS2MDL_CalcValue(uint16_t raw, float *final_value, bool isMag);
static void LIS2MDL_ReadData(uint8_t reg, float *final_value, bool isMag);

/* Private function definitions ----------------------------------------------*/

/**
  * @brief  Initialize the LIS3DH accelerometer.
  * @retval HAL_StatusTypeDef: HAL_OK if successful, otherwise error code
  */
static HAL_StatusTypeDef LIS3DH_Init(void) {
    uint8_t buf[2];
    HAL_StatusTypeDef status;

    /* Turn on normal mode and 1.344 kHz data rate */
    buf[0] = 0x20;      /* CTRL_REG_1 register */
    buf[1] = 0x97;      /* 0x97: enable normal mode, 1.344 kHz data rate */
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);
    if (status != HAL_OK) return status;

    /* Turn on block data update (for temperature sensing) */
    buf[0] = 0x23;      /* CTRL_REG_4 register */
    buf[1] = 0x80;      /* enable block data update */
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);
    if (status != HAL_OK) return status;

    /* Turn on auxiliary ADC (for temperature) */
    buf[0] = 0x1F;      /* TEMP_CFG_REG register */
    buf[1] = 0xC0;
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 100);

    return status;
}

/**
  * @brief  Convert the raw 16-bit sensor value to a float.
  * @param  raw_value: Raw data read from the sensor.
  * @param  final_value: Pointer to the float where the calculated value will be stored.
  * @param  isAccel: true if the value is an acceleration value, false if it is a temperature.
  */
static void LIS3DH_CalcValue(uint16_t raw_value, float *final_value, bool isAccel) {
    float scaling;
    float sensitivity = 0.004f; /* g per unit for acceleration */

    if (isAccel) {
        scaling = 64 / sensitivity;
    } else {
        scaling = 64;
    }
    /* raw_value is signed */
    *final_value = ((int16_t)raw_value) / scaling;
}

/**
  * @brief  Read two consecutive bytes from the specified register of LIS3DH and convert to a float.
  * @param  reg: Register address (LSB of the pair).
  * @param  final_value: Pointer to the float where the result will be stored.
  * @param  isAccel: true if reading acceleration, false for temperature.
  */
static void LIS3DH_ReadData(uint8_t reg, float *final_value, bool isAccel) {
    uint8_t data[2];
    /* Enable auto-increment by setting the MSB of the register address */
    HAL_I2C_Mem_Read(&hi2c1, (LIS3DH_ADDR << 1), reg | 0x80, I2C_MEMADD_SIZE_8BIT, data, 2, 100);
    uint16_t raw = (data[1] << 8) | data[0];
    LIS3DH_CalcValue(raw, final_value, isAccel);
}

/**
  * @brief  Initialize the LIS2MDL magnetometer.
  * @retval HAL_StatusTypeDef: HAL_OK if successful, otherwise error code
  */
static HAL_StatusTypeDef LIS2MDL_Init(void) {
    uint8_t buf[2];
    HAL_StatusTypeDef status;

    /* Configure CFG_REG_A: COMP_TEMP_EN = 1, continuous mode (MD = 00), default ODR (10 Hz) */
    buf[0] = 0x60;      /* CFG_REG_A register address */
    buf[1] = 0x80;      /* 0x80: temperature compensation enabled, continuous mode */
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 100);
    if (status != HAL_OK) return status;

    /* Configure CFG_REG_C: Enable DRDY on INT/DRDY pin (bit0 = 1) */
    buf[0] = 0x62;      /* CFG_REG_C register address */
    buf[1] = 0x01;      /* DRDY_on_PIN enabled */
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 100);

    return status;
}

/**
  * @brief  Convert raw 16-bit sensor data from LIS2MDL to a physical value.
  * @param  raw: Raw 16-bit value read from the sensor.
  * @param  final_value: Pointer where the converted value will be stored.
  * @param  isMag: true if converting magnetometer data, false if converting temperature.
  *
  * For magnetometer data, sensitivity ≈ 1.5 mgauss/LSB (i.e. 0.0015 gauss/LSB).
  * For temperature, the nominal sensitivity is 8 LSB/°C (i.e. 0.125 °C per LSB).
  */
static void LIS2MDL_CalcValue(uint16_t raw, float *final_value, bool isMag) {
    if (isMag) {
        *final_value = ((int16_t)raw) * 0.0015f;
    } else {
        *final_value = ((int16_t)raw) * 0.125f;
    }
}

/**
  * @brief  Read two consecutive bytes from a given register of the LIS2MDL and convert to a float.
  * @param  reg: Starting register address (LSB register). Auto-increment is enabled.
  * @param  final_value: Pointer to the float variable where the result will be stored.
  * @param  isMag: true if reading magnetometer data, false for temperature.
  */
static void LIS2MDL_ReadData(uint8_t reg, float *final_value, bool isMag) {
    uint8_t data[2];
    /* Enable auto-increment by setting the MSB of the register address */
    HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), reg | 0x80, I2C_MEMADD_SIZE_8BIT, data, 2, 100);
    uint16_t raw = (data[1] << 8) | data[0];
    LIS2MDL_CalcValue(raw, final_value, isMag);
}

/* Public function definitions -----------------------------------------------*/

/**
  * @brief  Initialize the IMU sensors (LIS3DH and LIS2MDL)
  * @retval bool: true if initialization successful, false if failed
  */
bool IMU_Init(void) {
    bool imu_ok = true;
    HAL_StatusTypeDef status;
    char msg[100];

    // Initialize LIS3DH and check for errors
    status = LIS3DH_Init();
    if (status != HAL_OK) {
        snprintf(msg, sizeof(msg), "ERROR: LIS3DH initialization failed! Error code: %d\r\n", status);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        imu_ok = false;
    }

    // Initialize LIS2MDL and check for errors
    status = LIS2MDL_Init();
    if (status != HAL_OK) {
        snprintf(msg, sizeof(msg), "ERROR: LIS2MDL initialization failed! Error code: %d\r\n", status);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        imu_ok = false;
    }

    if (imu_ok) {
        snprintf(msg, sizeof(msg), "IMU sensors initialization successful!\r\n");
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    }

    return imu_ok;
}

/**
  * @brief  Read data from both IMU sensors
  */
void IMU_ReadData(void) {
    // Read LIS3DH (Accelerometer & Temperature)
    LIS3DH_ReadData(0x28, &x_accel, true);
    LIS3DH_ReadData(0x2A, &y_accel, true);
    LIS3DH_ReadData(0x2C, &z_accel, true);
    LIS3DH_ReadData(0x0C, &lis3dh_temp, false);

    // Read LIS2MDL (Magnetometer & Temperature)
    LIS2MDL_ReadData(0x68, &x_mag, true);
    LIS2MDL_ReadData(0x6A, &y_mag, true);
    LIS2MDL_ReadData(0x6C, &z_mag, true);
    LIS2MDL_ReadData(0x6E, &lis2mdl_temp, false);
}

/**
  * @brief  Display IMU data over UART
  */
void IMU_DisplayData(void) {
    char msg[100];

    // Print LIS3DH data
    snprintf(msg, sizeof(msg), "--- LIS3DH Sensor ---\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Acceleration: X: %.3fg, Y: %.3fg, Z: %.3fg\r\n", x_accel, y_accel, z_accel);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "LIS3DH Temperature: %.3f%cC\r\n", lis3dh_temp, 0xB0);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Print LIS2MDL data
    snprintf(msg, sizeof(msg), "--- LIS2MDL Sensor ---\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "Magnetic Field: X: %.3f G, Y: %.3f G, Z: %.3f G\r\n", x_mag, y_mag, z_mag);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "LIS2MDL Temperature: %.3f%cC\r\n", lis2mdl_temp, 0xB0);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
}

/**
  * @brief  Get the current accelerometer X, Y, Z values
  * @param  x_out: Pointer to store X acceleration (g)
  * @param  y_out: Pointer to store Y acceleration (g)
  * @param  z_out: Pointer to store Z acceleration (g)
  * @retval None
  */
void IMU_GetAcceleration(float *x_out, float *y_out, float *z_out) {
    *x_out = x_accel;
    *y_out = y_accel;
    *z_out = z_accel;
}

/**
  * @brief  Get the current magnetometer X, Y, Z values
  * @param  x_out: Pointer to store X magnetic field (gauss)
  * @param  y_out: Pointer to store Y magnetic field (gauss)
  * @param  z_out: Pointer to store Z magnetic field (gauss)
  * @retval None
  */
void IMU_GetMagneticField(float *x_out, float *y_out, float *z_out) {
    *x_out = x_mag;
    *y_out = y_mag;
    *z_out = z_mag;
}

/**
  * @brief  Get temperature readings from both sensors
  * @param  accel_temp: Pointer to store accelerometer temperature (°C)
  * @param  mag_temp: Pointer to store magnetometer temperature (°C)
  * @retval None
  */
void IMU_GetTemperature(float *accel_temp, float *mag_temp) {
    *accel_temp = lis3dh_temp;
    *mag_temp = lis2mdl_temp;
}
