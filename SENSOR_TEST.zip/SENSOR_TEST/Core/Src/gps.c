/*
 * gps.c
 *
 *  Created on: Apr 1, 2025
 *      Author: William
 */

/* Includes ------------------------------------------------------------------*/
#include "gps.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Private variables ---------------------------------------------------------*/
/* GPS data structure */
static GPS_Data gpsData = {0};

/* NMEA processing buffers */
static uint8_t rxBuffer[BUFFER_SIZE];
static char nmeaSentence[BUFFER_SIZE];
static uint16_t rxIndex = 0;

/* Private function prototypes -----------------------------------------------*/
static void GPS_ParseNMEA(char* nmea_sentence);
static float GPS_ConvertNMEAtoDecimal(float value, char dir);
static uint8_t GPS_ValidateChecksum(const char* sentence);

/* Private function definitions ----------------------------------------------*/

/**
  * @brief  Calculate NMEA checksum and validate it
  * @param  sentence: NMEA sentence to validate
  * @retval uint8_t: 1 if checksum is valid, 0 if invalid
  */
static uint8_t GPS_ValidateChecksum(const char* sentence) {
    /* Check for minimum length and starting with '$' */
    if (sentence == NULL || strlen(sentence) < 5 || sentence[0] != '$') {
        return 0;
    }

    /* Find the checksum separator '*' */
    const char* checksumStart = strchr(sentence, '*');
    if (checksumStart == NULL || strlen(checksumStart) < 3) {
        return 0; /* No checksum found or too short */
    }

    /* Calculate checksum - XOR all characters between '$' and '*' */
    uint8_t calculatedChecksum = 0;
    for (const char* p = sentence + 1; p < checksumStart; p++) {
        calculatedChecksum ^= *p;
    }

    /* Convert the provided checksum from hex to int */
    char hexChecksum[3];
    hexChecksum[0] = checksumStart[1];
    hexChecksum[1] = checksumStart[2];
    hexChecksum[2] = '\0';

    uint8_t providedChecksum;
    sscanf(hexChecksum, "%hhx", &providedChecksum);

    return calculatedChecksum == providedChecksum;
}

/**
  * @brief  Convert NMEA format to decimal degrees
  * @param  value: NMEA format coordinate (ddmm.mmmm)
  * @param  dir: Direction character (N/S/E/W)
  * @retval float: Decimal degrees value
  */
static float GPS_ConvertNMEAtoDecimal(float value, char dir) {
    /* Extract degrees and minutes */
    int degrees = (int)(value / 100);
    float minutes = value - (degrees * 100);

    /* Convert to decimal degrees */
    float decimal = degrees + (minutes / 60);

    /* Apply direction (N/E are positive, S/W are negative) */
    if (dir == 'S' || dir == 'W') {
        decimal = -decimal;
    }

    return decimal;
}

/**
  * @brief  Parse NMEA sentence
  * @param  nmea: NMEA sentence to parse
  * @retval None
  */
static void GPS_ParseNMEA(char* nmea) {
    /* Validate checksum first */
    if (!GPS_ValidateChecksum(nmea)) {
        return; /* Invalid checksum, discard sentence */
    }

    char* token;
    char* rest = nmea;

    /* Store last sentence for debugging */
    strncpy(gpsData.last_sentence, nmea, BUFFER_SIZE-1);
    gpsData.last_sentence[BUFFER_SIZE-1] = '\0';

    /* Get the sentence identifier */
    token = strtok_r(rest, ",", &rest);

    if (token == NULL) return;

    /* Process GGA sentence (contains position data) */
    if (strcmp(token, "$GNGGA") == 0 || strcmp(token, "$GPGGA") == 0) {
        /* Time */
        token = strtok_r(rest, ",", &rest);

        /* Latitude */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.latitude = atof(token);
        } else {
            gpsData.latitude = 0.0;
        }

        /* N/S indicator */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.lat_dir = token[0];
        } else {
            gpsData.lat_dir = ' ';
        }

        /* Longitude */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.longitude = atof(token);
        } else {
            gpsData.longitude = 0.0;
        }

        /* E/W indicator */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.lon_dir = token[0];
        } else {
            gpsData.lon_dir = ' ';
        }

        /* Fix quality */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.fix_quality = atoi(token);
        } else {
            gpsData.fix_quality = 0;
        }

        /* Number of satellites */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.satellites = atoi(token);
        } else {
            gpsData.satellites = 0;
        }

        /* HDOP */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.hdop = atof(token);
        } else {
            gpsData.hdop = 0.0;
        }

        /* Altitude */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.altitude = atof(token);
        } else {
            gpsData.altitude = 0.0;
        }

        /* Mark data as valid if we have a fix */
        gpsData.valid = (gpsData.fix_quality > 0);

        /* Convert NMEA format to decimal degrees if we have valid coordinates */
        if (gpsData.valid && gpsData.latitude != 0.0 && gpsData.longitude != 0.0) {
            gpsData.latitude = GPS_ConvertNMEAtoDecimal(gpsData.latitude, gpsData.lat_dir);
            gpsData.longitude = GPS_ConvertNMEAtoDecimal(gpsData.longitude, gpsData.lon_dir);
        }
    }
    /* Process GSA sentence (contains DOP values and active satellites) */
    else if (strcmp(token, "$GNGSA") == 0 || strcmp(token, "$GPGSA") == 0) {
        /* Mode (M=Manual, A=Automatic) - skip */
        token = strtok_r(rest, ",", &rest);

        /* Fix type */
        token = strtok_r(rest, ",", &rest);
        if (token[0] != '\0') {
            gpsData.fix_type = atoi(token);
            /* Mark data as valid if we have a 2D or 3D fix */
            gpsData.valid = (gpsData.fix_type > 1);
        } else {
            gpsData.fix_type = 0;
        }

        /* Parse satellites used (12 fields) */
        for (int i = 0; i < 12; i++) {
            token = strtok_r(rest, ",", &rest);
            if (token != NULL && token[0] != '\0') {
                gpsData.sats_used[i] = atoi(token);
            } else {
                gpsData.sats_used[i] = 0;
            }
        }

        /* PDOP */
        token = strtok_r(rest, ",", &rest);
        if (token != NULL && token[0] != '\0') {
            gpsData.pdop = atof(token);
        }

        /* HDOP */
        token = strtok_r(rest, ",", &rest);
        if (token != NULL && token[0] != '\0') {
            gpsData.hdop_gsa = atof(token);
            /* If we haven't gotten HDOP from GGA, use this one */
            if (gpsData.hdop == 0.0) {
                gpsData.hdop = gpsData.hdop_gsa;
            }
        }

        /* VDOP */
        token = strtok_r(rest, ",", &rest);
        if (token != NULL && token[0] != '\0') {
            gpsData.vdop = atof(token);
        }
    }
    /* Process RMC sentence (Recommended Minimum data) */
    else if (strcmp(token, "$GNRMC") == 0 || strcmp(token, "$GPRMC") == 0) {
        /* Time */
        token = strtok_r(rest, ",", &rest);

        /* Status (A=active or V=void) */
        token = strtok_r(rest, ",", &rest);
        /* Valid if status is 'A' */
        if (token != NULL && token[0] == 'A') {
            gpsData.valid = 1;
        } else if (token != NULL && token[0] == 'V') {
            gpsData.valid = 0;
        }

        /* Skip other fields if only checking validity */
    }
}

/* Public function definitions -----------------------------------------------*/

/**
  * @brief  Initialize the GPS module
  * @retval None
  */
void GPS_Init(void) {
    /* Reset GPS data structure */
    memset(&gpsData, 0, sizeof(GPS_Data));
    rxIndex = 0;
}

/**
  * @brief  Process GPS data from UART
  * @retval None
  */
void GPS_ProcessData(void) {
    /* Read one byte at a time */
    uint8_t byte;
    HAL_StatusTypeDef status = HAL_UART_Receive(&huart2, &byte, 1, 10); /* Reduced timeout */

    if (status == HAL_OK) {
        /* Process the byte for NMEA sentence parsing */
        if (byte == '$') {
            /* Start of a new NMEA sentence */
            rxIndex = 0;
            nmeaSentence[rxIndex++] = byte;
        }
        else if (rxIndex > 0 && rxIndex < BUFFER_SIZE - 1) {
            /* Continue collecting the NMEA sentence */
            nmeaSentence[rxIndex++] = byte;

            /* Check for end of NMEA sentence (CR+LF) */
            if (byte == '\n' && rxIndex >= 5) {
                nmeaSentence[rxIndex] = '\0'; /* Null-terminate */

                /* Remove CR+LF from the end for cleaner display */
                if (rxIndex >= 2 && nmeaSentence[rxIndex-2] == '\r') {
                    nmeaSentence[rxIndex-2] = '\0';
                }

                /* Parse the complete NMEA sentence */
                GPS_ParseNMEA(nmeaSentence);
            }
        }
    }
}

/**
  * @brief  Display GPS data
  * @retval None
  */
void GPS_DisplayData(void) {
    char msg[100];

    /* Format individual fields with fixed buffer sizes */
    char latStr[30] = "unknown";
    if (gpsData.valid && gpsData.latitude != 0.0) {
        snprintf(latStr, sizeof(latStr), "%.6f %c", gpsData.latitude, gpsData.lat_dir);
    }

    char lonStr[30] = "unknown";
    if (gpsData.valid && gpsData.longitude != 0.0) {
        snprintf(lonStr, sizeof(lonStr), "%.6f %c", gpsData.longitude, gpsData.lon_dir);
    }

    char altStr[30] = "unknown";
    if (gpsData.valid && gpsData.altitude != 0.0) {
        snprintf(altStr, sizeof(altStr), "%.1f m", gpsData.altitude);
    }

    char satStr[30] = "unknown";
    if (gpsData.satellites > 0) {
        snprintf(satStr, sizeof(satStr), "%d", gpsData.satellites);
    } else {
        /* Count satellites from GSA */
        int count = 0;
        for (int i = 0; i < 12; i++) {
            if (gpsData.sats_used[i] > 0) {
                count++;
            }
        }

        if (count > 0) {
            snprintf(satStr, sizeof(satStr), "%d", count);
        }
    }

    char fixStr[30] = "unknown";
    if (gpsData.fix_quality > 0) {
        switch(gpsData.fix_quality) {
            case 0: strcpy(fixStr, "No fix"); break;
            case 1: strcpy(fixStr, "GPS fix"); break;
            case 2: strcpy(fixStr, "DGPS fix"); break;
            case 3: strcpy(fixStr, "PPS fix"); break;
            case 4: strcpy(fixStr, "RTK fix"); break;
            case 5: strcpy(fixStr, "Float RTK"); break;
            case 6: strcpy(fixStr, "Estimated"); break;
            default: snprintf(fixStr, sizeof(fixStr), "Type %d", gpsData.fix_quality);
        }
    } else if (gpsData.fix_type > 0) {
        switch(gpsData.fix_type) {
            case 1: strcpy(fixStr, "No fix"); break;
            case 2: strcpy(fixStr, "2D fix"); break;
            case 3: strcpy(fixStr, "3D fix"); break;
            default: snprintf(fixStr, sizeof(fixStr), "Type %d (GSA)", gpsData.fix_type);
        }
    }

    /* Clean up the NMEA sentence for display */
    char sentenceDisplay[BUFFER_SIZE];
    strncpy(sentenceDisplay, gpsData.last_sentence, sizeof(sentenceDisplay) - 1);
    sentenceDisplay[sizeof(sentenceDisplay) - 1] = '\0';

    /* Remove any trailing CR/LF */
    size_t len = strlen(sentenceDisplay);
    while (len > 0 && (sentenceDisplay[len-1] == '\r' || sentenceDisplay[len-1] == '\n')) {
        sentenceDisplay[--len] = '\0';
    }

    /* Create parts of the message separately with proper size checking */
    char headerMsg[] = "\r\n======== GPS DATA ========\r\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)headerMsg, strlen(headerMsg), HAL_MAX_DELAY);

    char latMsg[50];
    snprintf(latMsg, sizeof(latMsg), "Latitude:   %s\r\n", latStr);
    HAL_UART_Transmit(&huart3, (uint8_t*)latMsg, strlen(latMsg), HAL_MAX_DELAY);

    char lonMsg[50];
    snprintf(lonMsg, sizeof(lonMsg), "Longitude:  %s\r\n", lonStr);
    HAL_UART_Transmit(&huart3, (uint8_t*)lonMsg, strlen(lonMsg), HAL_MAX_DELAY);

    char altMsg[50];
    snprintf(altMsg, sizeof(altMsg), "Altitude:   %s\r\n", altStr);
    HAL_UART_Transmit(&huart3, (uint8_t*)altMsg, strlen(altMsg), HAL_MAX_DELAY);

    char satMsg[50];
    snprintf(satMsg, sizeof(satMsg), "Satellites: %s\r\n", satStr);
    HAL_UART_Transmit(&huart3, (uint8_t*)satMsg, strlen(satMsg), HAL_MAX_DELAY);

    char fixMsg[50];
    snprintf(fixMsg, sizeof(fixMsg), "Fix Type:   %s\r\n", fixStr);
    HAL_UART_Transmit(&huart3, (uint8_t*)fixMsg, strlen(fixMsg), HAL_MAX_DELAY);

    char sentMsg[100];
    snprintf(sentMsg, sizeof(sentMsg), "Sentence:   %s\r\n", sentenceDisplay);
    HAL_UART_Transmit(&huart3, (uint8_t*)sentMsg, strlen(sentMsg), HAL_MAX_DELAY);

    char footerMsg[] = "==========================\r\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)footerMsg, strlen(footerMsg), HAL_MAX_DELAY);
}

/**
  * @brief  Get the current GPS data struct
  * @retval GPS_Data: Current GPS data
  */
GPS_Data GPS_GetData(void) {
    return gpsData;
}

/**
  * @brief  Check if valid GPS fix is available
  * @retval bool: true if valid fix available, false otherwise
  */
bool GPS_HasValidFix(void) {
    return (gpsData.valid != 0);
}
